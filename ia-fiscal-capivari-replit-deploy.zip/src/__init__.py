# IA Fiscal Capivari
# Municipal spending monitoring and alerting system